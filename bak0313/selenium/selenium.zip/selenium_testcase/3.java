package com.example.tests;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class 3 {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "http://diapers.qa.diaperscorp.com/?enablelog=y";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void test3() throws Exception {
    driver.get(baseUrl + "/?enablelog=y");
    // ERROR: Caught exception [ERROR: Unsupported command [deleteAllVisibleCookies |  | ]]
    driver.findElement(By.id("searchInput")).clear();
    driver.findElement(By.id("searchInput")).sendKeys("vv-001");
    driver.findElement(By.id("searchImageButton")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [deleteAllVisibleCookies |  | ]]
    driver.findElement(By.cssSelector("span.product-item-name-product")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [deleteAllVisibleCookies |  | ]]
    driver.findElement(By.id("addPersonalizationCheckBox")).click();
    driver.findElement(By.id("addPersonalizationLabel")).click();
    driver.findElement(By.id("personalizationCategory2")).click();
    driver.findElement(By.linkText("next")).click();
    driver.findElement(By.id("itemSimple_Script")).click();
    driver.findElement(By.linkText("next")).click();
    driver.findElement(By.id("itemWhite")).click();
    driver.findElement(By.linkText("next")).click();
    driver.findElement(By.id("firstLineTextBox")).clear();
    driver.findElement(By.id("firstLineTextBox")).sendKeys("asd");
    driver.findElement(By.id("secondLineTextBox")).clear();
    driver.findElement(By.id("secondLineTextBox")).sendKeys("ASDSS");
    driver.findElement(By.linkText("next")).click();
    driver.findElement(By.linkText("apply")).click();
    driver.findElement(By.id("AddCartButton")).click();
    driver.findElement(By.id("addPersonalizationCheckBox")).click();
    driver.findElement(By.id("zipCodeInput")).clear();
    driver.findElement(By.id("zipCodeInput")).sendKeys("12306");
    driver.findElement(By.id("InputZipCodeButton")).click();
    driver.findElement(By.cssSelector("div.quidsiCloseBtn")).click();
    driver.findElement(By.id("diaperItemTR0")).click();
    driver.findElement(By.id("diaperItemTR0")).click();
    driver.findElement(By.id("TotalAmountLabel")).click();
    driver.findElement(By.linkText("edit")).click();
    driver.findElement(By.xpath("//div[@id='personalizationContentDiv']/div[2]/ul/li[3]/label")).click();
    driver.findElement(By.cssSelector("a.next")).click();
    driver.findElement(By.id("itemBlock")).click();
    driver.findElement(By.cssSelector("a.next.right")).click();
    driver.findElement(By.xpath("//div[@id='personalizationContentDiv']/div[2]/ul/li[12]/label")).click();
    driver.findElement(By.id("itemPurple")).click();
    driver.findElement(By.cssSelector("a.next.right")).click();
    driver.findElement(By.id("firstInitialTextBox")).clear();
    driver.findElement(By.id("firstInitialTextBox")).sendKeys("2");
    driver.findElement(By.id("secondInitialTextBox")).clear();
    driver.findElement(By.id("secondInitialTextBox")).sendKeys("1");
    driver.findElement(By.id("thirdInitialTextBox")).clear();
    driver.findElement(By.id("thirdInitialTextBox")).sendKeys("3");
    driver.findElement(By.cssSelector("a.next.right")).click();
    driver.findElement(By.cssSelector("a.apply.right")).click();
    try {
      assertEquals("3 Initials:", driver.findElement(By.xpath("//li[2]/b")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
