package com.example.tests;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Ptest1 {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "http://diapers.qa.diaperscorp.com/?enablelog=y";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testPtest1() throws Exception {
    // ERROR: Caught exception [ERROR: Unsupported command [setTimeout | 60000 | ]]
    // ERROR: Caught exception [ERROR: Unsupported command [setSpeed | 3000 | ]]
    String site1 = "diapers.qa.diaperscorp.com";
    driver.get("http://" + site1);
    // ERROR: Caught exception [ERROR: Unsupported command [deleteAllVisibleCookies |  | ]]
    driver.navigate().refresh();
    driver.findElement(By.id("searchInput")).clear();
    driver.findElement(By.id("searchInput")).sendKeys("vv-001");
    driver.findElement(By.id("searchImageButton")).click();
    driver.findElement(By.cssSelector("span.product-item-name-product")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [deleteAllVisibleCookies |  | ]]
    driver.findElement(By.id("addPersonalizationLabel")).click();
    driver.findElement(By.id("personalizationCategory2")).click();
    driver.findElement(By.linkText("next")).click();
    driver.findElement(By.id("itemSimple_Script")).click();
    driver.findElement(By.linkText("next")).click();
    driver.findElement(By.id("itemWhite")).click();
    driver.findElement(By.linkText("next")).click();
    driver.findElement(By.id("firstLineTextBox")).clear();
    driver.findElement(By.id("firstLineTextBox")).sendKeys("asd");
    driver.findElement(By.id("secondLineTextBox")).clear();
    driver.findElement(By.id("secondLineTextBox")).sendKeys("ASDSS");
    driver.findElement(By.linkText("next")).click();
    driver.findElement(By.linkText("apply")).click();
    driver.findElement(By.id("AddCartButton")).click();
    driver.findElement(By.id("addPersonalizationCheckBox")).click();
    driver.findElement(By.id("TotalAmountLabel")).click();
    driver.findElement(By.linkText("edit")).click();
    for (int second = 0;; second++) {
    	if (second >= 60) fail("timeout");
    	try { if (isElementPresent(By.xpath("//div[@id='personalizationContentDiv']/div[2]/ul/li[3]/label"))) break; } catch (Exception e) {}
    	Thread.sleep(1000);
    }

    driver.findElement(By.xpath("//div[@id='personalizationContentDiv']/div[2]/ul/li[3]/label")).click();
    driver.findElement(By.cssSelector("a.next")).click();
    driver.findElement(By.xpath("//div[@id='personalizationContentDiv']/div[2]/ul/li[2]/label")).click();
    driver.findElement(By.cssSelector("a.next.right")).click();
    driver.findElement(By.xpath("//li[11]/label")).click();
    driver.findElement(By.cssSelector("a.next")).click();
    driver.findElement(By.id("firstInitialTextBox")).clear();
    driver.findElement(By.id("firstInitialTextBox")).sendKeys("a");
    driver.findElement(By.id("secondInitialTextBox")).clear();
    driver.findElement(By.id("secondInitialTextBox")).sendKeys("b");
    driver.findElement(By.id("thirdInitialTextBox")).clear();
    driver.findElement(By.id("thirdInitialTextBox")).sendKeys("c");
    driver.findElement(By.cssSelector("a.next.right")).click();
    driver.findElement(By.cssSelector("a.apply.right")).click();
    try {
      assertEquals("3 Initials:", driver.findElement(By.xpath("//li[2]/b")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    // ERROR: Caught exception [unknown command []]
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
