<?php 
	header("Content-Type:text/html; charset=utf-8");
	echo "<h6>{$_REQUEST['name']}</h6>";
?>
