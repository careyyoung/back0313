<?php
   echo "Hello Ajax!";
?>